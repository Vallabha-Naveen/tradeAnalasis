/**
 * Order execution module.
 *
 * Converts trade analysis results (symbol + option type) into Fyers orders.
 * Handles symbol token lookup, strike price selection, and order placement.
 */

import { logger } from '../utils/logger.js';
import { FyersClient } from './client.js';
import type { OrderParams } from './client.js';
import type { OptionType } from '../models/Trade.js';

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export interface TradeSignal {
  symbol: 'NIFTY' | 'BANKNIFTY';
  optionType: OptionType;
  confidence: number;
  timestamp: Date;
}

export interface OrderExecutionResult {
  success: boolean;
  orderId?: string;
  message: string;
  dryRun: boolean;
  orderDetails?: OrderParams;
}

export interface AtmStrikeInfo {
  strike: number;
  symbolToken: string;
  spotPrice: number;
}

// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------

// Lot sizes for NIFTY and BANKNIFTY
const LOT_SIZES: Record<string, number> = {
  NIFTY: 25,
  BANKNIFTY: 15,
};

// Fyers symbol format: NSE:NIFTY23600CE or NSE:BANKNIFTY44800CE
// Format: NSE:{SYMBOL}{STRIKE}{TYPE}
// Example: NSE:NIFTY23600CE means NIFTY 23600 CE

// ---------------------------------------------------------------------------
// ATM Strike Detection
// ---------------------------------------------------------------------------

/**
 * Get the current ATM strike for a given symbol.
 * 
 * This queries the Fyers API for the current spot price and calculates
 * the nearest strike price (ATM). Strike prices are typically at 50-point
 * intervals for NIFTY and 100-point intervals for BANKNIFTY.
 */
export async function getAtmStrike(
  client: FyersClient,
  symbol: 'NIFTY' | 'BANKNIFTY',
): Promise<AtmStrikeInfo | null> {
  try {
    // Get the index spot price
    const indexSymbol = `NSE:${symbol}-INDEX`;
    const quote = await client.getQuote(indexSymbol);
    
    if (!quote || !quote.v || quote.v.lp === undefined) {
      logger.error(`Failed to get spot price for ${symbol}`);
      return null;
    }
    
    const spotPrice = quote.v.lp;
    logger.info(`${symbol} spot price: ${spotPrice}`);
    
    // Calculate strike interval
    const strikeInterval = symbol === 'NIFTY' ? 50 : 100;
    
    // Calculate ATM strike (round to nearest interval)
    const atmStrike = Math.round(spotPrice / strikeInterval) * strikeInterval;
    
    // Generate the option symbol
    const optionSymbol = `NSE:${symbol}${atmStrike}CE`; // We'll adjust for PE later
    
    // Get the quote to verify the symbol exists
    const optionQuote = await client.getQuote(optionSymbol);
    
    if (!optionQuote) {
      logger.error(`Failed to get quote for ATM strike ${atmStrike}`);
      return null;
    }
    
    const symbolToken = optionQuote.v?.symbol_token || '';
    
    logger.info(`ATM strike for ${symbol}: ${atmStrike}, token: ${symbolToken}`);
    
    return {
      strike: atmStrike,
      symbolToken,
      spotPrice,
    };
  } catch (err) {
    logger.error('Failed to get ATM strike', { error: String(err), symbol });
    return null;
  }
}

/**
 * Generate the Fyers option symbol for a given strike and option type.
 */
export function generateOptionSymbol(
  symbol: 'NIFTY' | 'BANKNIFTY',
  strike: number,
  optionType: OptionType,
): string {
  return `NSE:${symbol}${strike}${optionType}`;
}

// ---------------------------------------------------------------------------
// Order Execution
// ---------------------------------------------------------------------------

/**
 * Execute a trade signal by placing an order on Fyers.
 * 
 * This function:
 * 1. Validates the signal (confidence threshold, market hours)
 * 2. Determines the strike price (ATM for now)
 * 3. Constructs the order parameters
 * 4. Places the order (or logs it in dry-run mode)
 */
export async function executeTrade(
  client: FyersClient,
  signal: TradeSignal,
  dryRun: boolean = true,
  maxOrderValue: number = 50000,
): Promise<OrderExecutionResult> {
  try {
    // Validate confidence threshold
    const confidenceThreshold = parseInt(process.env['CONFIDENCE_THRESHOLD'] || '70');
    if (signal.confidence < confidenceThreshold) {
      const msg = `Signal confidence ${signal.confidence}% below threshold ${confidenceThreshold}%`;
      logger.warn(msg);
      return {
        success: false,
        message: msg,
        dryRun,
      };
    }

    // Check market hours (9:15 AM - 3:30 PM IST)
    const now = new Date();
    const istTime = new Date(now.toLocaleString('en-US', { timeZone: 'Asia/Kolkata' }));
    const hours = istTime.getHours();
    const minutes = istTime.getMinutes();
    const timeInMinutes = hours * 60 + minutes;
    
    const marketOpen = 9 * 60 + 15; // 9:15 AM
    const marketClose = 15 * 60 + 30; // 3:30 PM
    
    if (timeInMinutes < marketOpen || timeInMinutes > marketClose) {
      const msg = `Market closed (current time: ${hours}:${minutes.toString().padStart(2, '0')})`;
      logger.warn(msg);
      return {
        success: false,
        message: msg,
        dryRun,
      };
    }

    // Get ATM strike
    const atmInfo = await getAtmStrike(client, signal.symbol);
    if (!atmInfo) {
      return {
        success: false,
        message: 'Failed to determine ATM strike',
        dryRun,
      };
    }

    // Generate option symbol
    const optionSymbol = generateOptionSymbol(
      signal.symbol,
      atmInfo.strike,
      signal.optionType,
    );

    // Get current option price
    const optionQuote = await client.getQuote(optionSymbol);
    if (!optionQuote || !optionQuote.v || optionQuote.v.lp === undefined) {
      return {
        success: false,
        message: 'Failed to get option price',
        dryRun,
      };
    }

    const optionPrice = optionQuote.v.lp;
    const lotSize = LOT_SIZES[signal.symbol];
    if (!lotSize) {
      return {
        success: false,
        message: `Unknown lot size for symbol ${signal.symbol}`,
        dryRun,
      };
    }
    const orderValue = optionPrice * lotSize;

    // Check max order value
    if (orderValue > maxOrderValue) {
      const msg = `Order value ₹${orderValue.toFixed(2)} exceeds max ₹${maxOrderValue}`;
      logger.warn(msg);
      return {
        success: false,
        message: msg,
        dryRun,
      };
    }

    // Construct order parameters
    const orderParams: OrderParams = {
      symbol: optionSymbol,
      qty: lotSize,
      type: 1, // MARKET order
      side: 1, // BUY (long position)
      productType: 'INTRADAY',
      limitPrice: 0,
      stopLoss: 0,
      takeProfit: 0,
      validity: 'DAY',
      disclosedQty: 0,
      offlineOrder: false,
      orderTag: 'telegram-auto',
    };

    logger.info('Order parameters', {
      symbol: optionSymbol,
      qty: lotSize,
      price: optionPrice,
      value: orderValue,
      side: 'BUY',
      type: 'MARKET',
    });

    // Execute order (or log in dry-run mode)
    if (dryRun) {
      logger.info('[DRY RUN] Would place order:', orderParams);
      return {
        success: true,
        message: 'Dry run - order logged but not placed',
        dryRun: true,
        orderDetails: orderParams,
      };
    } else {
      const response = await client.placeOrder(orderParams);
      
      if (response.s === 'ok') {
        logger.info(`Order placed successfully: ${response.id}`);
        return {
          success: true,
          orderId: response.id,
          message: 'Order placed successfully',
          dryRun: false,
          orderDetails: orderParams,
        };
      } else {
        logger.error(`Order placement failed: ${response.message}`);
        return {
          success: false,
          message: response.message,
          dryRun: false,
        };
      }
    }
  } catch (err) {
    logger.error('Failed to execute trade', { error: String(err), signal });
    return {
      success: false,
      message: `Execution error: ${String(err)}`,
      dryRun,
    };
  }
}
