/**
 * Risk management module.
 *
 * Implements trading safeguards including:
 * - Daily loss limit
 * - Max daily trades
 * - Max open positions
 * - Order value limits
 * - Cooldown between trades
 */

import { logger } from '../utils/logger.js';
import { FyersClient } from './client.js';

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export interface RiskCheckResult {
  allowed: boolean;
  reason?: string;
}

export interface DailyStats {
  totalTrades: number;
  totalPnl: number;
  lastTradeTime: Date | null;
}

export interface RiskConfig {
  dailyLossLimit: number;
  maxDailyTrades: number;
  maxOpenPositions: number;
  maxOrderValue: number;
  cooldownMinutes: number;
}

// ---------------------------------------------------------------------------
// Daily stats tracking (in-memory for now, could be persisted to DB)
// ---------------------------------------------------------------------------

let dailyStats: DailyStats = {
  totalTrades: 0,
  totalPnl: 0,
  lastTradeTime: null,
};

/**
 * Reset daily stats (call at start of each trading day).
 */
export function resetDailyStats(): void {
  dailyStats = {
    totalTrades: 0,
    totalPnl: 0,
    lastTradeTime: null,
  };
  logger.info('Daily risk stats reset');
}

/**
 * Update daily stats after a trade.
 */
export function updateDailyStats(pnl: number): void {
  dailyStats.totalTrades++;
  dailyStats.totalPnl += pnl;
  dailyStats.lastTradeTime = new Date();
  
  logger.info('Daily stats updated', {
    trades: dailyStats.totalTrades,
    pnl: dailyStats.totalPnl,
  });
}

/**
 * Get current daily stats.
 */
export function getDailyStats(): DailyStats {
  return { ...dailyStats };
}

// ---------------------------------------------------------------------------
// Risk checks
// ---------------------------------------------------------------------------

/**
 * Check if a trade is allowed based on risk management rules.
 */
export async function checkRiskLimits(
  client: FyersClient,
  config: RiskConfig,
  orderValue: number,
): Promise<RiskCheckResult> {
  try {
    // Check 1: Daily loss limit
    if (dailyStats.totalPnl < -config.dailyLossLimit) {
      const msg = `Daily loss limit reached: ₹${dailyStats.totalPnl.toFixed(2)} (limit: -₹${config.dailyLossLimit})`;
      logger.warn(msg);
      return { allowed: false, reason: msg };
    }

    // Check 2: Max daily trades
    if (dailyStats.totalTrades >= config.maxDailyTrades) {
      const msg = `Max daily trades reached: ${dailyStats.totalTrades} (limit: ${config.maxDailyTrades})`;
      logger.warn(msg);
      return { allowed: false, reason: msg };
    }

    // Check 3: Max order value
    if (orderValue > config.maxOrderValue) {
      const msg = `Order value ₹${orderValue.toFixed(2)} exceeds max ₹${config.maxOrderValue}`;
      logger.warn(msg);
      return { allowed: false, reason: msg };
    }

    // Check 4: Max open positions
    const positions = await client.getPositions();
    const openPositions = positions.filter(p => p.qty !== 0).length;
    
    if (openPositions >= config.maxOpenPositions) {
      const msg = `Max open positions reached: ${openPositions} (limit: ${config.maxOpenPositions})`;
      logger.warn(msg);
      return { allowed: false, reason: msg };
    }

    // Check 5: Cooldown between trades
    if (dailyStats.lastTradeTime) {
      const cooldownMs = config.cooldownMinutes * 60 * 1000;
      const timeSinceLastTrade = Date.now() - dailyStats.lastTradeTime.getTime();
      
      if (timeSinceLastTrade < cooldownMs) {
        const remainingSeconds = Math.ceil((cooldownMs - timeSinceLastTrade) / 1000);
        const msg = `Cooldown active: ${remainingSeconds}s remaining`;
        logger.warn(msg);
        return { allowed: false, reason: msg };
      }
    }

    // Check 6: Available margin
    const funds = await client.getFunds();
    if (funds.available_margin < orderValue) {
      const msg = `Insufficient margin: ₹${funds.available_margin.toFixed(2)} available, need ₹${orderValue.toFixed(2)}`;
      logger.warn(msg);
      return { allowed: false, reason: msg };
    }

    // All checks passed
    logger.debug('All risk checks passed');
    return { allowed: true };
  } catch (err) {
    logger.error('Risk check failed', { error: String(err) });
    return { allowed: false, reason: `Risk check error: ${String(err)}` };
  }
}

/**
 * Load risk config from environment variables.
 */
export function loadRiskConfig(): RiskConfig {
  return {
    dailyLossLimit: parseInt(process.env['DAILY_LOSS_LIMIT'] || '10000'),
    maxDailyTrades: parseInt(process.env['MAX_DAILY_TRADES'] || '20'),
    maxOpenPositions: parseInt(process.env['MAX_OPEN_POSITIONS'] || '5'),
    maxOrderValue: parseInt(process.env['MAX_ORDER_VALUE'] || '50000'),
    cooldownMinutes: parseInt(process.env['COOLDOWN_MINUTES'] || '5'),
  };
}
