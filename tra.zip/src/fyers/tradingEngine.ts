/**
 * Trading engine - ties together all Fyers trading components.
 *
 * This module provides the main entry point for executing trades:
 * - Authentication and client initialization
 * - Trade signal processing
 * - Risk management checks
 * - Order execution
 * - Dry-run mode support
 */

import { logger } from '../utils/logger.js';
import { FyersClient } from './client.js';
import { generateAuthUrl, exchangeAuthCode, loadTokens, refreshAccessToken, type FyersAuthConfig, type FyersTokenData } from './auth.js';
import { executeTrade, type TradeSignal, type OrderExecutionResult } from './orderExecutor.js';
import { checkRiskLimits, loadRiskConfig, resetDailyStats, updateDailyStats, type RiskConfig } from './riskManager.js';
import type { OptionType } from '../models/Trade.js';
import fs from 'fs';
import path from 'path';

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export interface TradingEngineConfig {
  auth: FyersAuthConfig;
  risk: RiskConfig;
  dryRun: boolean;
}

export interface TradingEngine {
  initialize(): Promise<void>;
  processTradeSignal(signal: TradeSignal): Promise<OrderExecutionResult>;
  getAuthUrl(): string;
  shutdown(): void;
}

// ---------------------------------------------------------------------------
// Trading Engine Implementation
// ---------------------------------------------------------------------------

export class DefaultTradingEngine implements TradingEngine {
  private config: TradingEngineConfig;
  private client: FyersClient | null = null;
  private tokenData: FyersTokenData | null = null;
  private isInitialized = false;

  constructor(config: TradingEngineConfig) {
    this.config = config;
  }

  /**
   * Initialize the trading engine.
   * 
   * This will:
   * 1. Load saved tokens if available
   * 2. If no tokens, user needs to visit auth URL
   * 3. Create Fyers client
   * 4. Reset daily stats if new trading day
   */
  async initialize(): Promise<void> {
    if (this.isInitialized) {
      logger.warn('Trading engine already initialized');
      return;
    }

    try {
      // Try to load saved tokens
      this.tokenData = loadTokens();

      if (!this.tokenData) {
        logger.info('No saved tokens found. User needs to authenticate.');
        logger.info('Visit this URL to get auth code:');
        logger.info(this.getAuthUrl());
        throw new Error('Authentication required. Please authenticate first.');
      }

      // Check if token needs refresh
      if (this.tokenData.expiresAt < Date.now()) {
        logger.info('Access token expired, refreshing...');
        if (this.tokenData.refreshToken) {
          this.tokenData = await refreshAccessToken(this.config.auth, this.tokenData.refreshToken);
        } else {
          throw new Error('Token expired and no refresh token available. Please re-authenticate.');
        }
      }

      // Create Fyers client
      this.client = new FyersClient(this.config.auth, this.tokenData);
      
      // Test connection
      const profile = await this.client.getProfile();
      if (!profile) {
        throw new Error('Failed to connect to Fyers API');
      }

      logger.info('Trading engine initialized successfully');
      logger.info(`Dry-run mode: ${this.config.dryRun ? 'ENABLED' : 'DISABLED'}`);
      
      // Reset daily stats if new trading day
      this.checkAndResetDailyStats();

      this.isInitialized = true;
    } catch (err) {
      logger.error('Failed to initialize trading engine', { error: String(err) });
      throw err;
    }
  }

  /**
   * Authenticate with auth code (call this after user visits auth URL).
   */
  async authenticate(authCode: string): Promise<void> {
    try {
      logger.info('Exchanging auth code for access token...');
      this.tokenData = await exchangeAuthCode(this.config.auth, authCode);
      
      // Create client
      this.client = new FyersClient(this.config.auth, this.tokenData);
      
      // Test connection
      await this.client.getProfile();
      
      logger.info('Authentication successful');
      this.isInitialized = true;
    } catch (err) {
      logger.error('Authentication failed', { error: String(err) });
      throw err;
    }
  }

  /**
   * Get the authentication URL for the user to visit.
   */
  getAuthUrl(): string {
    return generateAuthUrl(this.config.auth);
  }

  /**
   * Process a trade signal and execute the trade.
   */
  async processTradeSignal(signal: TradeSignal): Promise<OrderExecutionResult> {
    if (!this.isInitialized || !this.client) {
      throw new Error('Trading engine not initialized. Call initialize() first.');
    }

    try {
      logger.info('Processing trade signal', {
        symbol: signal.symbol,
        optionType: signal.optionType,
        confidence: signal.confidence,
      });

      // Get ATM strike info to calculate order value
      const atmInfo = await executeTrade(
        this.client,
        signal,
        true, // Always dry-run first to get order details
        this.config.risk.maxOrderValue,
      );

      if (!atmInfo.success || !atmInfo.orderDetails) {
        return atmInfo;
      }

      // Calculate order value
      const orderValue = atmInfo.orderDetails.qty * 100; // Approximate, will be refined in executeTrade

      // Run risk checks
      const riskCheck = await checkRiskLimits(
        this.client,
        this.config.risk,
        orderValue,
      );

      if (!riskCheck.allowed) {
        logger.warn(`Trade rejected by risk manager: ${riskCheck.reason}`);
        return {
          success: false,
          message: riskCheck.reason || 'Risk check failed',
          dryRun: this.config.dryRun,
        };
      }

      // Execute trade (with actual dry-run setting)
      const result = await executeTrade(
        this.client,
        signal,
        this.config.dryRun,
        this.config.risk.maxOrderValue,
      );

      // Update daily stats if trade was successful
      if (result.success) {
        // For now, assume 0 P&L (will be updated from order book later)
        updateDailyStats(0);
      }

      return result;
    } catch (err) {
      logger.error('Failed to process trade signal', { error: String(err), signal });
      return {
        success: false,
        message: `Processing error: ${String(err)}`,
        dryRun: this.config.dryRun,
      };
    }
  }

  /**
   * Check if it's a new trading day and reset stats if needed.
   */
  private checkAndResetDailyStats(): void {
    const today = new Date().toISOString().split('T')[0];
    const statePath = path.join(process.cwd(), 'config', 'trading-state.json');
    
    let lastTradeDate: string | null = null;
    try {
      if (fs.existsSync(statePath)) {
        const state = JSON.parse(fs.readFileSync(statePath, 'utf-8'));
        lastTradeDate = state.lastTradeDate || null;
      }
    } catch (err) {
      logger.warn('Failed to read trading state', { error: String(err) });
    }
    
    if (lastTradeDate !== today) {
      logger.info('New trading day detected, resetting daily stats');
      resetDailyStats();
      
      // Save new state
      try {
        const dir = path.dirname(statePath);
        if (!fs.existsSync(dir)) {
          fs.mkdirSync(dir, { recursive: true });
        }
        fs.writeFileSync(statePath, JSON.stringify({ lastTradeDate: today }, null, 2));
      } catch (err) {
        logger.warn('Failed to save trading state', { error: String(err) });
      }
    }
  }

  /**
   * Shutdown the trading engine.
   */
  shutdown(): void {
    logger.info('Shutting down trading engine');
    this.client = null;
    this.isInitialized = false;
  }
}

// ---------------------------------------------------------------------------
// Factory function
// ---------------------------------------------------------------------------

/**
 * Create a trading engine with configuration from environment variables.
 */
export function createTradingEngine(): TradingEngine {
  const authConfig: FyersAuthConfig = {
    appId: process.env['FYERS_APP_ID'] || '',
    appSecret: process.env['FYERS_APP_SECRET'] || '',
    redirectUri: process.env['FYERS_REDIRECT_URI'] || 'http://localhost:8080',
  };

  const riskConfig = loadRiskConfig();

  const dryRun = process.env['DRY_RUN'] !== 'false';

  const config: TradingEngineConfig = {
    auth: authConfig,
    risk: riskConfig,
    dryRun,
  };

  return new DefaultTradingEngine(config);
}

/**
 * Create a trade signal from analysis results.
 */
export function createTradeSignal(
  symbol: 'NIFTY' | 'BANKNIFTY',
  optionType: OptionType,
  confidence: number,
): TradeSignal {
  return {
    symbol,
    optionType,
    confidence,
    timestamp: new Date(),
  };
}
