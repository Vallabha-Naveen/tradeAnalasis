/**
 * Fyers API client wrapper.
 *
 * Provides a high-level interface to Fyers API operations including:
 * - Order placement
 * - Order book queries
 * - Position queries
 * - Fund queries
 * - Quote queries
 */

import path from 'path';
import { logger } from '../utils/logger.js';
import type { FyersAuthConfig, FyersTokenData } from './auth.js';

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export interface OrderParams {
  symbol: string;
  qty: number;
  type: 1 | 2; // 1 = MARKET, 2 = LIMIT
  side: 1 | -1; // 1 = BUY, -1 = SELL
  productType: string;
  limitPrice?: number;
  stopLoss?: number;
  takeProfit?: number;
  validity: string;
  disclosedQty?: number;
  offlineOrder: boolean;
  orderTag?: string;
}

export interface OrderResponse {
  s: string;
  code: number;
  message: string;
  id?: string;
  orderBook?: any[];
}

export interface QuoteResponse {
  s: string;
  code: number;
  message: string;
  d?: any[];
}

export interface Position {
  symbol: string;
  qty: number;
  side: string;
  pnl: number;
  avg_price: number;
}

export interface Funds {
  equity: number;
  available_margin: number;
  used_margin: number;
}

// ---------------------------------------------------------------------------
// Client class
// ---------------------------------------------------------------------------

export class FyersClient {
  private fyersInstance: any;
  private accessToken: string;
  private config: FyersAuthConfig;

  constructor(config: FyersAuthConfig, tokenData: FyersTokenData) {
    this.config = config;
    this.accessToken = tokenData.accessToken;
  }

  /**
   * Initialize the Fyers API instance.
   * Must be called before using other methods.
   */
  private async initFyers(): Promise<void> {
    if (this.fyersInstance) {
      return;
    }

    try {
      // Disable SSL verification for Fyers API (required due to certificate issues)
      process.env['NODE_TLS_REJECT_UNAUTHORIZED'] = '0';
      
      const fyersApi = await import('fyers-api-v3');
      const fyersModel = fyersApi.fyersModel;

      this.fyersInstance = new fyersModel({
        path: path.resolve(process.cwd(), 'logs'),
        enableLogging: true,
      });

      this.fyersInstance.setAppId(this.config.appId);
      this.fyersInstance.setRedirectUrl(this.config.redirectUri);
      this.fyersInstance.setAccessToken(this.accessToken);

      // Re-enable SSL verification after initialization
      process.env['NODE_TLS_REJECT_UNAUTHORIZED'] = '1';

      logger.debug('Fyers API client initialized');
    } catch (err) {
      // Re-enable SSL verification even on error
      process.env['NODE_TLS_REJECT_UNAUTHORIZED'] = '1';
      logger.error('Failed to initialize Fyers API client', { error: String(err) });
      throw err;
    }
  }

  /**
   * Update access token (e.g., after refresh).
   */
  updateAccessToken(newToken: string): void {
    this.accessToken = newToken;
    this.fyersInstance = null; // Force re-initialization
    logger.info('Fyers access token updated');
  }

  // ---------------------------------------------------------------------------
  // Order operations
  // ---------------------------------------------------------------------------

  /**
   * Place a new order.
   */
  async placeOrder(params: OrderParams): Promise<OrderResponse> {
    await this.initFyers();

    try {
      // Disable SSL verification for Fyers API
      process.env['NODE_TLS_REJECT_UNAUTHORIZED'] = '0';
      
      const response = await this.fyersInstance.place_order(params);
      
      // Re-enable SSL verification
      process.env['NODE_TLS_REJECT_UNAUTHORIZED'] = '1';
      
      const result = response as OrderResponse;

      if (result.s === 'ok') {
        logger.info(`Order placed successfully: ${result.id}`);
      } else {
        logger.error(`Order placement failed: ${result.message}`);
      }

      return result;
    } catch (err) {
      // Re-enable SSL verification even on error
      process.env['NODE_TLS_REJECT_UNAUTHORIZED'] = '1';
      logger.error('Failed to place order', { error: String(err), params });
      throw err;
    }
  }

  /**
   * Get order book (all orders).
   */
  async getOrderBook(): Promise<any> {
    await this.initFyers();

    try {
      process.env['NODE_TLS_REJECT_UNAUTHORIZED'] = '0';
      const response = await this.fyersInstance.get_order_book();
      process.env['NODE_TLS_REJECT_UNAUTHORIZED'] = '1';
      logger.debug('Retrieved order book');
      return response;
    } catch (err) {
      process.env['NODE_TLS_REJECT_UNAUTHORIZED'] = '1';
      logger.error('Failed to get order book', { error: String(err) });
      throw err;
    }
  }

  /**
   * Cancel an order by ID.
   */
  async cancelOrder(orderId: string): Promise<OrderResponse> {
    await this.initFyers();

    try {
      process.env['NODE_TLS_REJECT_UNAUTHORIZED'] = '0';
      const response = await this.fyersInstance.cancel_order({ id: orderId });
      process.env['NODE_TLS_REJECT_UNAUTHORIZED'] = '1';
      const result = response as OrderResponse;

      if (result.s === 'ok') {
        logger.info(`Order cancelled: ${orderId}`);
      } else {
        logger.error(`Order cancellation failed: ${result.message}`);
      }

      return result;
    } catch (err) {
      process.env['NODE_TLS_REJECT_UNAUTHORIZED'] = '1';
      logger.error('Failed to cancel order', { error: String(err), orderId });
      throw err;
    }
  }

  // ---------------------------------------------------------------------------
  // Position operations
  // ---------------------------------------------------------------------------

  /**
   * Get current positions.
   */
  async getPositions(): Promise<Position[]> {
    await this.initFyers();

    try {
      process.env['NODE_TLS_REJECT_UNAUTHORIZED'] = '0';
      const response = await this.fyersInstance.get_positions();
      process.env['NODE_TLS_REJECT_UNAUTHORIZED'] = '1';
      logger.debug('Retrieved positions');
      return response?.netPositions || [];
    } catch (err) {
      process.env['NODE_TLS_REJECT_UNAUTHORIZED'] = '1';
      logger.error('Failed to get positions', { error: String(err) });
      throw err;
    }
  }

  // ---------------------------------------------------------------------------
  // Fund operations
  // ---------------------------------------------------------------------------

  /**
   * Get available funds and margin.
   */
  async getFunds(): Promise<Funds> {
    await this.initFyers();

    try {
      process.env['NODE_TLS_REJECT_UNAUTHORIZED'] = '0';
      const response = await this.fyersInstance.get_funds();
      process.env['NODE_TLS_REJECT_UNAUTHORIZED'] = '1';
      
      const funds: Funds = {
        equity: response?.fund_limit?.[0]?.equityAmount || 0,
        available_margin: response?.fund_limit?.[0]?.netAvailableMargin || 0,
        used_margin: response?.fund_limit?.[0]?.utilizedMargin || 0,
      };

      logger.debug('Retrieved funds', funds);
      return funds;
    } catch (err) {
      process.env['NODE_TLS_REJECT_UNAUTHORIZED'] = '1';
      logger.error('Failed to get funds', { error: String(err) });
      throw err;
    }
  }

  // ---------------------------------------------------------------------------
  // Quote operations
  // ---------------------------------------------------------------------------

  /**
   * Get quotes for symbols.
   */
  async getQuotes(symbols: string[]): Promise<QuoteResponse> {
    await this.initFyers();

    try {
      process.env['NODE_TLS_REJECT_UNAUTHORIZED'] = '0';
      const response = await this.fyersInstance.get_quotes({ symbols: symbols.join(',') });
      process.env['NODE_TLS_REJECT_UNAUTHORIZED'] = '1';
      logger.debug('Retrieved quotes', { symbols });
      return response as QuoteResponse;
    } catch (err) {
      process.env['NODE_TLS_REJECT_UNAUTHORIZED'] = '1';
      logger.error('Failed to get quotes', { error: String(err), symbols });
      throw err;
    }
  }

  /**
   * Get quote for a single symbol.
   */
  async getQuote(symbol: string): Promise<any> {
    const response = await this.getQuotes([symbol]);
    
    if (response.s === 'ok' && response.d && response.d.length > 0) {
      return response.d[0];
    }
    
    return null;
  }

  // ---------------------------------------------------------------------------
  // Profile operations
  // ---------------------------------------------------------------------------

  /**
   * Get user profile.
   */
  async getProfile(): Promise<any> {
    await this.initFyers();

    try {
      process.env['NODE_TLS_REJECT_UNAUTHORIZED'] = '0';
      const response = await this.fyersInstance.get_profile();
      process.env['NODE_TLS_REJECT_UNAUTHORIZED'] = '1';
      logger.debug('Retrieved user profile');
      return response;
    } catch (err) {
      process.env['NODE_TLS_REJECT_UNAUTHORIZED'] = '1';
      logger.error('Failed to get profile', { error: String(err) });
      throw err;
    }
  }
}
