/**
 * Live listener — POLLS a Telegram channel every 250 ms for new trade signals.
 *
 * This replaces the previous gramJS `addEventHandler` + `NewMessage` push
 * model with an explicit polling loop. Every 250 ms we ask Telegram for
 * messages newer than the highest id we've already seen, then run each new
 * photo message through the same pipeline as before.
 *
 * Pipeline per new photo message:
 *   1. Poll channel for messages with id > lastSeenMessageId (every 250 ms)
 *   2. For each new message (processed oldest-first):
 *        a. Photo-only filter (skip text/video/sticker/etc.)
 *        b. Download photo
 *        c. Insert placeholder DB record (audit trail even if analysis fails)
 *        d. Validate screenshot (orientation, colored header bar, etc.)
 *        e. Analyze:
 *             - Symbol: whitespace-based OCR (same as offline)
 *             - Option type: VLM primary (glm-4v), OCR fallback
 *        f. Update DB record with analysis results
 *        g. If trading enabled → acquire mutex → execute SELL order
 *   3. Advance lastSeenMessageId to the highest id processed in this batch
 *
 * WHY POLLING INSTEAD OF EVENT LISTENER
 * -------------------------------------
 *   - Predictable: no dependency on gramJS's internal event-loop dispatch.
 *   - Resumable: lastSeenMessageId is derived from the DB on restart, so
 *     messages that arrived while the process was down are picked up on
 *     the next start (the event-listener version lost anything that
 *     arrived during downtime).
 *   - Simpler error isolation: a single failed poll logs and is skipped;
 *     the loop keeps running. A throw inside an event handler can leave
 *     the listener in a half-broken state.
 *
 * POLL OVERLAP SAFETY
 * -------------------
 * A single `getMessages` round-trip can take longer than 250 ms on a slow
 * link. We therefore use a self-scheduling `setTimeout` chain (NOT
 * `setInterval`): the next poll is scheduled only AFTER the previous one
 * completes, with a 250 ms gap. If a poll takes >250 ms, the next one
 * fires immediately on completion — no overlap, no queue buildup.
 *
 * DETECTOR CONFIG
 * ---------------
 * Controlled by OPTION_TYPE_DETECTOR env var:
 *   - "vlm"       (default) VLM primary, OCR fallback if VLM fails
 *   - "ocr"                  OCR only (no VLM dependency)
 *   - "vlm-only"             VLM only, skip trade if VLM fails
 */

import { TelegramClient } from 'telegram';
import { Api } from 'telegram';

import { logger } from '../utils/logger.js';
import { errToString } from '../utils/errors.js';
import { downloadMessagePhoto } from './mediaDownloader.js';
import { validateScreenshot } from '../analyzer/validateScreenshot.js';
import { ocrHeaderOnce } from '../analyzer/unifiedHeaderOcr.js';
import {
  detectByWhitespace,
  detectByWhitespaceFromOcr,
} from '../analyzer/detectSymbolByWhitespace.js';
import {
  detectOptionTypeFromHeaderOcr,
  detectOptionTypeByOcr,
} from '../analyzer/detectOptionType.js';
import {
  detectOptionTypeByVlm,
  checkVlmAvailability,
} from '../analyzer/detectOptionTypeVLM.js';
import { clampConfidence, type DetectionScore } from '../analyzer/confidence.js';
import { createTradingEngine, createTradeSignal } from '../fyers/tradingEngine.js';
import type { TradingEngine } from '../fyers/tradingEngine.js';
import type { OptionType } from '../models/Trade.js';
import { AsyncMutex } from '../utils/concurrency.js';
import { getDb } from '../database/db.js';
import { TradeRepository } from '../database/tradeRepository.js';
import path from 'path';
import dotenv from 'dotenv';

dotenv.config();

// ---------------------------------------------------------------------------
// Polling configuration
// ---------------------------------------------------------------------------

/** Poll interval — fetch new messages every 250 ms. */
const POLL_INTERVAL_MS = 250;

/**
 * Maximum messages to fetch per poll. 50 is plenty for 250 ms windows —
 * a channel would need to post >200 msgs/sec to overflow this in a single
 * tick. If it ever does, the next poll picks up the rest (we advance
 * lastSeenMessageId only up to what we actually processed).
 */
const POLL_LIMIT = 50;

// ---------------------------------------------------------------------------
// Concurrency: only ONE order may be in-flight at a time.
// ---------------------------------------------------------------------------
const orderMutex = new AsyncMutex();

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export interface LiveListenerConfig {
  channelUsername: string;
  enableTrading: boolean;
}

interface EnrichedConfig extends LiveListenerConfig {
  /** Resolved numeric channel ID (as string) — used for DB scoping */
  channelId: string;
  /** Which option-type detector to use */
  detector: 'vlm' | 'ocr' | 'vlm-only';
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

/**
 * Start polling the configured channel every 250 ms for new messages.
 *
 * @returns The trading engine (so the caller can shut it down on exit) and
 *          a `stop()` function that cancels the polling loop on shutdown.
 */
export async function startLiveListener(
  client: TelegramClient,
  config: LiveListenerConfig,
): Promise<{ tradingEngine: TradingEngine | null; stop: () => void }> {
  logger.info(
    `Starting live listener (polling every ${POLL_INTERVAL_MS}ms) for channel: ${config.channelUsername}`,
  );
  logger.info(`Trading enabled: ${config.enableTrading}`);

  // 1. Initialize trading engine (if enabled)
  let tradingEngine: TradingEngine | null = null;
  if (config.enableTrading) {
    try {
      tradingEngine = createTradingEngine();
      await tradingEngine.initialize();
      logger.info('Trading engine initialized');
    } catch (err) {
      const errStr = errToString(err);
      logger.error('Failed to initialize trading engine', { error: errStr });
      if (errStr.includes('Authentication required') || errStr.includes('fyers-auth')) {
        logger.info('Run `npm run fyers-auth` to authenticate with Fyers.');
      }
      throw err;
    }
  }

  // 2. Initialize DB
  const db = getDb();
  const repo = new TradeRepository(db);

  // 3. Resolve the channel entity ONCE — we'll pass it directly to
  //    getMessages on every poll. No need for in-handler chat filtering
  //    because we're explicitly asking Telegram for messages from this
  //    entity only.
  const normalizedUsername = config.channelUsername.replace('@', '');
  let channelId: string;
  let channelEntity: any;
  try {
    channelEntity = await client.getEntity(normalizedUsername);
    channelId = String(channelEntity.id);
    const accessHash = (channelEntity as any).accessHash
      ? String((channelEntity as any).accessHash)
      : undefined;
    logger.info(
      `Resolved channel @${normalizedUsername} → ID ${channelId}` +
        (accessHash ? ` (accessHash: ${accessHash})` : ''),
    );
  } catch (err) {
    logger.error(
      `Cannot resolve channel @${config.channelUsername}. ` +
        `Make sure your Telegram account has access.`,
      { error: errToString(err) },
    );
    throw err;
  }

  // 4. Determine which detector to use
  const detectorCfg = (process.env['OPTION_TYPE_DETECTOR'] || 'vlm').toLowerCase().trim();
  let detector: 'vlm' | 'ocr' | 'vlm-only' = 'vlm';
  if (detectorCfg === 'ocr') detector = 'ocr';
  else if (detectorCfg === 'vlm-only') detector = 'vlm-only';

  if (detector !== 'ocr') {
    logger.info('Checking VLM detector availability...');
    const vlmCheck = await checkVlmAvailability();
    if (!vlmCheck.available) {
      logger.warn('VLM detector is NOT available:');
      for (const line of (vlmCheck.reason || '').split('\n')) {
        logger.warn('  ' + line);
      }
      if (detector === 'vlm-only') {
        logger.warn('Falling back to "vlm" mode (OCR fallback enabled) since VLM-only requires VLM.');
        detector = 'vlm';
      }
      logger.warn('VLM calls will fail per-image and fall back to OCR. To use VLM, fix the configuration above.');
    } else {
      logger.info('✓ VLM detector available and configured.');
    }
  }
  logger.info(`Option-type detector: ${detector}`);

  const enrichedConfig: EnrichedConfig = { ...config, channelId, detector };

  // 5. Initialize the polling watermark (`lastSeenMessageId`).
  //
  //    Strategy:
  //      a) If the DB already has records for this channel, resume from the
  //         highest message id we've previously recorded. This gives us
  //         crash recovery — anything that arrived while the process was
  //         down gets picked up on the next start.
  //      b) If the DB is empty (first run on this channel), fetch the
  //         channel's current latest message and start from there. This
  //         matches the original event-listener behavior of "start from
  //         now, don't replay channel history."
  //      c) If the channel has no messages at all, start from 0.
  let lastSeenMessageId = 0;

  const dbMaxRow = db
    .prepare(
      'SELECT MAX(telegram_message_id) AS max_id FROM trades WHERE telegram_channel_id = ?',
    )
    .get(channelId) as { max_id: number | null } | undefined;
  const dbMaxId = dbMaxRow?.max_id ?? 0;
  if (dbMaxId > 0) {
    lastSeenMessageId = dbMaxId;
    logger.info(
      `Resuming from last recorded message ID ${lastSeenMessageId} (from DB). ` +
        `Any messages that arrived during downtime will be picked up.`,
    );
  } else {
    const latestMsgs = await client.getMessages(channelEntity, { limit: 1 });
    if (latestMsgs.length > 0 && latestMsgs[0] instanceof Api.Message) {
      lastSeenMessageId = latestMsgs[0].id;
      logger.info(
        `No prior DB records — starting from current latest message ID ${lastSeenMessageId} ` +
          `(historical messages will NOT be replayed).`,
      );
    } else {
      lastSeenMessageId = 0;
      logger.info('Channel appears empty — will start from the first message.');
    }
  }

  // 6. Start the polling loop.
  //
  //    We use a self-scheduling `setTimeout` chain instead of `setInterval`
  //    so that a slow poll (network RTT > 250 ms) doesn't cause overlapping
  //    `getMessages` calls. The next poll is scheduled 250 ms AFTER the
  //    previous one completes.
  let stopped = false;
  let timer: NodeJS.Timeout | null = null;
  let pollInFlight = false;

  const pollOnce = async (): Promise<void> => {
    if (pollInFlight || stopped) return;
    pollInFlight = true;
    try {
      // Fetch up to POLL_LIMIT messages with id > lastSeenMessageId.
      // gramJS returns newest-first; we sort ascending below so the
      // oldest new message is processed first (preserves chronological
      // order for trade execution).
      const fetched = await client.getMessages(channelEntity, {
        limit: POLL_LIMIT,
        minId: lastSeenMessageId,
      });

      if (fetched.length === 0) {
        return; // No new messages — the common case
      }

      // Keep only real Api.Message instances (skip service messages etc.)
      // and dedup against the watermark defensively (some MTProto layers
      // interpret min_id as inclusive rather than exclusive).
      const msgs = fetched
        .filter((m): m is Api.Message => m instanceof Api.Message)
        .filter((m) => m.id > lastSeenMessageId)
        .sort((a, b) => a.id - b.id); // oldest-first

      if (msgs.length === 0) {
        return;
      }

      logger.debug(
        `Poll fetched ${msgs.length} new message(s) (ids ${msgs[0].id}..${msgs[msgs.length - 1].id})`,
      );

      let highestId = lastSeenMessageId;
      for (const message of msgs) {
        // Advance the watermark for THIS batch. The DB UNIQUE constraint on
        // (channel_id, message_id) protects us if we somehow re-fetch the
        // same id after a restart — `insertPlaceholder` returns the existing
        // record instead of erroring.
        highestId = Math.max(highestId, message.id);

        try {
          await handleMessage(message, client, enrichedConfig, tradingEngine, repo);
        } catch (err) {
          // Log and continue — one bad message shouldn't stop the loop.
          logger.error('Error handling polled message', {
            error: errToString(err),
            messageId: message.id,
          });
        }
      }

      // Commit the watermark for the batch only after all messages in the
      // batch have been attempted (so a mid-batch crash re-fetches the
      // unprocessed tail on restart — safely deduped by the DB).
      lastSeenMessageId = highestId;
    } catch (err) {
      // Network blip, FloodWait, etc. — log and keep polling. gramJS
      // handles most retries internally; we just don't want the loop to die.
      logger.error('Poll iteration failed — will retry on next tick', {
        error: errToString(err),
      });
    } finally {
      pollInFlight = false;
    }
  };

  const scheduleNext = (): void => {
    if (stopped) return;
    timer = setTimeout(async () => {
      await pollOnce();
      scheduleNext();
    }, POLL_INTERVAL_MS);
  };

  scheduleNext();
  logger.info('Live listener started successfully — polling for new messages...');

  const stop = (): void => {
    if (stopped) return;
    stopped = true;
    if (timer) {
      clearTimeout(timer);
      timer = null;
    }
    logger.info('Live listener stopped (polling cancelled).');
  };

  return { tradingEngine, stop };
}

// ---------------------------------------------------------------------------
// Per-message handler
// ---------------------------------------------------------------------------

/**
 * Process a single polled photo message end-to-end.
 *
 * Identical pipeline to the previous event-listener version — only the
 * delivery mechanism (poll vs push) has changed.
 */
async function handleMessage(
  message: Api.Message,
  client: TelegramClient,
  config: EnrichedConfig,
  tradingEngine: TradingEngine | null,
  repo: TradeRepository,
): Promise<void> {
  // 1. Photo-only filter — ignore text/video/sticker/etc.
  //    (Channel filtering is unnecessary here: we polled this specific
  //    channel entity, so every message we receive is from it.)
  if (!message.photo) {
    logger.debug(`Message ${message.id} has no photo, skipping`);
    return;
  }

  logger.info(`>>> New photo message detected (msg ${message.id}) <<<`);

  // 2. Download photo
  const downloadDir =
    process.env['DOWNLOAD_DIRECTORY'] || path.join(process.cwd(), 'downloads', 'raw');
  const imagePath = await downloadMessagePhoto(client, message, downloadDir);
  if (!imagePath) {
    logger.error(`Failed to download photo for message ${message.id}`);
    return;
  }
  logger.info(`Photo downloaded: ${imagePath}`);

  // 3. Insert placeholder DB record (audit trail)
  const msgTime = new Date((message.date as number) * 1000);
  const caption = (message.message as string) ?? '';
  const trade = repo.insertPlaceholder({
    telegramMessageId: message.id,
    telegramChannelId: config.channelId,
    telegramMessageTime: msgTime,
    imagePath,
    caption,
  });

  // 4. Validate screenshot
  const validation = await validateScreenshot(imagePath);
  if (!validation.valid) {
    logger.info(`Screenshot validation failed: ${validation.reason}`);
    if (trade) {
      repo.updateAnalysis(trade.id, {
        symbol: null,
        optionType: null,
        confidence: 0,
        method: null,
        parserVersion: 'live-1.1.0',
      });
    }
    return;
  }
  logger.info('Screenshot validation passed');

  // 5. Analyze
  const analysisResult = await analyzeScreenshot(imagePath, config.detector);
  logger.info(
    `Analysis: symbol=${analysisResult.symbol} optionType=${analysisResult.optionType} ` +
      `confidence=${analysisResult.confidence}% method=${analysisResult.method}`,
  );

  // 6. Update DB with analysis results
  if (trade) {
    repo.updateAnalysis(trade.id, {
      symbol: analysisResult.symbol,
      optionType: analysisResult.optionType,
      confidence: analysisResult.confidence,
      method: analysisResult.method || null,
      parserVersion: 'live-1.1.0',
    });
  }

  // 7. Execute trade if enabled + analysis succeeded
  if (!analysisResult.symbol || !analysisResult.optionType) {
    logger.warn('Analysis incomplete — skipping trade');
    return;
  }

  if (!config.enableTrading || !tradingEngine) {
    logger.info('Trading disabled, skipping order execution');
    return;
  }

  // Serialize order placement
  const result = await orderMutex.run(async () => {
    const signal = createTradeSignal(
      analysisResult.symbol as 'NIFTY' | 'BANKNIFTY',
      analysisResult.optionType as 'CE' | 'PE',
      analysisResult.confidence,
      message.id,
    );
    logger.info(`Executing trade for message ${message.id} (serialized)...`);
    return tradingEngine!.processTradeSignal(signal);
  });

  if (result.success) {
    logger.info(`Trade executed: ${result.orderId || 'dry-run'}`);
  } else {
    logger.warn(`Trade execution failed: ${result.message}`);
  }
}

// ---------------------------------------------------------------------------
// Analysis pipeline
// ---------------------------------------------------------------------------

interface AnalysisResult {
  symbol: string | null;
  optionType: OptionType | null;
  confidence: number;
  method: string | null;
}

/**
 * Run the analysis pipeline on a single screenshot.
 *
 * PARALLEL EXECUTION
 * ------------------
 * Symbol detection (OCR) and option-type detection (VLM or OCR) run in
 * PARALLEL because they don't depend on each other. This cuts end-to-end
 * latency roughly in half vs. serial execution.
 *
 * Concretely, in `vlm` mode the timeline looks like:
 *
 *   t=0      -+- OCR (unified header)  --> symbolScore (whitespace)
 *              +- VLM API call          --> optionScore
 *   t=max(ocr,vlm)
 *
 * If the symbol's single-pass OCR fails, the fallback (full OCR re-run)
 * only starts AFTER the parallel phase completes - but that's rare and
 * the option-type result is already known by then.
 *
 * Option-type detection strategy:
 *   - "vlm":       VLM primary, OCR fallback if VLM fails
 *   - "ocr":       OCR only
 *   - "vlm-only":  VLM only (returns null if VLM fails)
 */
async function analyzeScreenshot(
  imagePath: string,
  detector: 'vlm' | 'ocr' | 'vlm-only',
): Promise<AnalysisResult> {
  // -----------------------------------------------------------------------
  // Phase 1: Run symbol detection and option-type detection IN PARALLEL.
  // -----------------------------------------------------------------------
  // Memoized unified OCR - runs ONCE, shared by both symbol detection and
  // option-type OCR fallback.
  const ocrPromise = ocrHeaderOnce(imagePath).catch((err) => {
    throw new Error(`Unified OCR failed: ${errToString(err)}`);
  });

  // Symbol detection: depends on unified OCR, may fall back to full re-OCR
  const symbolPromise: Promise<{
    score: DetectionScore<string>;
    ocrFailed: boolean;
  }> = ocrPromise
    .then(async (ocrResult) => {
      let score = detectByWhitespaceFromOcr(ocrResult);
      if (!score.value) {
        logger.debug('Single-pass symbol detection failed, falling back to original method');
        score = await detectByWhitespace(imagePath);
      }
      return { score, ocrFailed: false };
    })
    .catch((err) => {
      // Unified OCR failed entirely - try the standalone whitespace method
      logger.warn('Unified OCR failed for symbol detection, trying standalone method', {
        error: errToString(err),
      });
      return detectByWhitespace(imagePath).then((score) => ({ score, ocrFailed: true }));
    });

  // Option-type detection
  const optionPromise: Promise<DetectionScore<OptionType>> = (async () => {
    if (detector === 'ocr') {
      // OCR-only mode: use the shared unified OCR result
      try {
        const ocrResult = await ocrPromise;
        let score = detectOptionTypeFromHeaderOcr(ocrResult);
        if (!score.value) {
          logger.debug('Single-pass CE/PE failed, falling back to multi-strategy OCR');
          score = await detectOptionTypeByOcr(imagePath);
        }
        return score;
      } catch {
        // Unified OCR failed - fall back to multi-strategy OCR directly
        return detectOptionTypeByOcr(imagePath);
      }
    }

    // VLM mode (or vlm-only): call VLM first
    logger.info('Calling VLM for option-type detection...');
    const vlmScore = await detectOptionTypeByVlm(imagePath);
    if (vlmScore.value) {
      logger.info(`VLM detected: ${vlmScore.value} (${vlmScore.confidence}%)`);
      return vlmScore;
    }

    // VLM failed
    if (detector === 'vlm-only') {
      logger.warn('VLM failed in vlm-only mode, no fallback - option type unknown');
      return vlmScore; // null value
    }

    // vlm mode: fall back to OCR using the shared unified OCR result
    logger.warn('VLM detection failed or returned UNKNOWN, falling back to OCR');
    try {
      const ocrResult = await ocrPromise;
      let score = detectOptionTypeFromHeaderOcr(ocrResult);
      if (!score.value) {
        score = await detectOptionTypeByOcr(imagePath);
      }
      return score;
    } catch {
      // Unified OCR also failed - last resort: multi-strategy OCR
      return detectOptionTypeByOcr(imagePath);
    }
  })();

  // -----------------------------------------------------------------------
  // Phase 2: Await both results in parallel (they're already running).
  // -----------------------------------------------------------------------
  const [symbolResult, optionScore] = await Promise.all([symbolPromise, optionPromise]);
  const symbolScore = symbolResult.score;

  const symbol = symbolScore.value;
  const optionType = optionScore.value;
  const sConf = symbolScore.confidence;
  const oConf = optionScore.confidence;

  // Confidence blend - matches analyze.ts
  let confidence: number;
  if (sConf === 0 && oConf === 0) {
    confidence = 0;
  } else if (sConf > 0 && oConf > 0) {
    confidence = clampConfidence(sConf * 0.6 + oConf * 0.4);
  } else {
    confidence = clampConfidence(Math.max(sConf, oConf));
  }

  let method: string | null = null;
  if (symbolScore.value && optionScore.value) {
    method =
      symbolScore.confidence >= optionScore.confidence
        ? symbolScore.method
        : optionScore.method;
  } else if (symbolScore.value) {
    method = symbolScore.method;
  } else if (optionScore.value) {
    method = optionScore.method;
  }

  return { symbol, optionType, confidence, method };
}
