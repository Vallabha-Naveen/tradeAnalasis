/**
 * Live trading script.
 *
 * This script starts the live listener that monitors Telegram channel
 * for trade signals and executes them via Fyers API.
 *
 * Usage: npm run live-trade
 *
 * Prerequisites:
 * 1. Run npm run fyers-auth to authenticate with Fyers
 * 2. Set DRY_RUN=false in .env to enable real trading (default is true)
 */

import dotenv from 'dotenv';

import { startLiveListener } from '../telegram/liveListener.js';
import { authenticate, disconnect } from '../telegram/auth.js';
import input from 'input';

dotenv.config();

async function main(): Promise<void> {
  console.log('=== Live Trading Mode ===\n');

  const channelUsername = process.env['CHANNEL_USERNAME'];
  const dryRun = process.env['DRY_RUN'] !== 'false';

  if (!channelUsername) {
    console.error('ERROR: CHANNEL_USERNAME must be set in .env file');
    process.exit(1);
  }

  console.log(`Channel: ${channelUsername}`);
  console.log(`Dry-run mode: ${dryRun ? 'ENABLED (no real trades)' : 'DISABLED (real trades!)'}`);
  console.log();

  if (!dryRun) {
    console.log('⚠️  WARNING: Real trading is enabled!');
    console.log('⚠️  Make sure you have proper risk controls in place.');
    console.log();
    const confirm = await input.text('Type "CONFIRM" to proceed: ');
    if (confirm !== 'CONFIRM') {
      console.log('Aborted.');
      process.exit(0);
    }
  }

  try {
    // Authenticate with Telegram
    console.log('Connecting to Telegram...');
    const client = await authenticate();

    // Start live listener
    await startLiveListener(client, {
      channelUsername,
      enableTrading: true,
    });

    console.log('\nLive trading started. Press Ctrl+C to stop.');
    console.log('Monitoring channel for trade signals...\n');

    // Keep the process running
    process.on('SIGINT', async () => {
      console.log('\n\nShutting down...');
      await disconnect(client);
      console.log('Disconnected.');
      process.exit(0);
    });

  } catch (err) {
    console.error('Fatal error:', err);
    process.exit(1);
  }
}

main().catch((err) => {
  console.error('Fatal error:', err);
  process.exit(1);
});
