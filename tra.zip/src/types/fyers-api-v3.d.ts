/**
 * Type declarations for fyers-api-v3 package.
 * This is a CommonJS package without TypeScript definitions.
 */

declare module 'fyers-api-v3' {
  export class fyersModel {
    constructor(config: { path?: string; enableLogging?: boolean });
    
    setAppId(appId: string): void;
    setRedirectUrl(redirectUrl: string): void;
    setAccessToken(accessToken: string): void;
    
    generate_access_token(params: {
      client_id: string;
      secret_key: string;
      auth_code: string;
    }): Promise<any>;
    
    get_profile(): Promise<any>;
    
    place_order(params: any): Promise<any>;
    
    get_quotes(params: any): Promise<any>;
    
    get_order_book(): Promise<any>;
    
    get_positions(): Promise<any>;
    
    get_funds(): Promise<any>;
  }
  
  export class fyersOrderSocket {
    constructor(config: any);
    
    connect(): void;
    
    subscribe(orderIds: string[]): void;
    
    on(event: string, callback: (data: any) => void): void;
    
    close(): void;
  }
  
  export class fyersDataSocket {
    constructor(config: any);
    
    connect(): void;
    
    subscribe(symbols: string[]): void;
    
    on(event: string, callback: (data: any) => void): void;
    
    close(): void;
  }
}
