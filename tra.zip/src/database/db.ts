/**
 * Database connection module.
 *
 * Opens (or creates) the SQLite database and runs migrations.
 * Exports a singleton `getDb()` function.
 */

import Database from 'better-sqlite3';
import path from 'path';
import fs from 'fs';
import { logger } from '../utils/logger.js';
import { config } from '../config/config.js';
import { runMigrations } from './schema.js';

let _db: Database.Database | null = null;

/**
 * Get the singleton database connection.
 * Creates the database file and runs migrations on first call.
 */
export function getDb(): Database.Database {
  if (_db) {
    return _db;
  }

  const dbPath = config.paths.database;
  const dbDir = path.dirname(dbPath);

  // Ensure the database directory exists
  if (!fs.existsSync(dbDir)) {
    fs.mkdirSync(dbDir, { recursive: true });
    logger.info(`Created database directory: ${dbDir}`);
  }

  logger.info(`Opening database: ${dbPath}`);
  _db = new Database(dbPath);

  // Enable WAL mode for better concurrent read performance
  _db.pragma('journal_mode = WAL');
  _db.pragma('foreign_keys = ON');

  // Run schema migrations
  runMigrations(_db);
  logger.info('Database migrations complete');

  return _db;
}

/**
 * Close the database connection.
 * Call this during graceful shutdown.
 */
export function closeDb(): void {
  if (_db) {
    _db.close();
    _db = null;
    logger.info('Database connection closed');
  }
}