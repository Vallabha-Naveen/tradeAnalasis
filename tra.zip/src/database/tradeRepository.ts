/**
 * Trade repository — all database operations for the trades table.
 *
 * Each method is a thin wrapper around a prepared statement.
 * The repository does NOT contain business logic.
 */

import type BetterSqlite3 from 'better-sqlite3';
import type { CreateTradeInput, Trade, TradeRow } from '../models/Trade.js';
import { rowToTrade } from '../models/Trade.js';
import { logger } from '../utils/logger.js';

// ---------------------------------------------------------------------------
// snake_case → camelCase mapper for SQLite rows
// ---------------------------------------------------------------------------

/** Column name mapping: SQLite snake_case → TradeRow camelCase */
const COLUMN_MAP: Record<string, keyof TradeRow> = {
  id: 'id',
  telegram_message_id: 'telegramMessageId',
  telegram_channel_id: 'telegramChannelId',
  telegram_message_time: 'telegramMessageTime',
  symbol: 'symbol',
  option_type: 'optionType',
  strike: 'strike',
  quantity: 'quantity',
  confidence: 'confidence',
  detection_method: 'detectionMethod',
  image_path: 'imagePath',
  processed_at: 'processedAt',
  inserted_at: 'insertedAt',
  parser_version: 'parserVersion',
  caption: 'caption',
};

/**
 * Convert a raw SQLite row (snake_case keys) to a TradeRow (camelCase keys).
 */
function toTradeRow(raw: Record<string, unknown>): TradeRow {
  const result = {} as Record<string, unknown>;
  for (const [key, value] of Object.entries(raw)) {
    const mapped = COLUMN_MAP[key];
    if (mapped) {
      result[mapped] = value;
    }
  }
  return result as unknown as TradeRow;
}

export class TradeRepository {
  private readonly db: BetterSqlite3.Database;

  constructor(db: BetterSqlite3.Database) {
    this.db = db;
  }

  // -----------------------------------------------------------------------
  // Create
  // -----------------------------------------------------------------------

  /**
   * Insert a placeholder record for a downloaded image (no analysis yet).
   * Used by download-only mode — analysis is done later by the analyze script.
   */
  insertPlaceholder(input: {
    telegramMessageId: number;
    telegramChannelId: string;
    telegramMessageTime: Date;
    imagePath: string;
    caption: string;
  }): Trade | null {
    const now = new Date().toISOString();
    const msgTime = input.telegramMessageTime.toISOString();

    try {
      const stmt = this.db.prepare(`
        INSERT INTO trades (
          telegram_message_id,
          telegram_channel_id,
          telegram_message_time,
          symbol,
          option_type,
          strike,
          quantity,
          confidence,
          detection_method,
          image_path,
          processed_at,
          inserted_at,
          parser_version,
          caption
        ) VALUES (
          @telegramMessageId,
          @telegramChannelId,
          @telegramMessageTime,
          NULL,
          NULL,
          NULL,
          NULL,
          0,
          NULL,
          @imagePath,
          @processedAt,
          @insertedAt,
          @parserVersion,
          @caption
        )
      `);

      stmt.run({
        telegramMessageId: input.telegramMessageId,
        telegramChannelId: input.telegramChannelId,
        telegramMessageTime: msgTime,
        imagePath: input.imagePath,
        processedAt: msgTime,
        insertedAt: now,
        parserVersion: '0.0.0',
        caption: input.caption,
      });

      const raw = this.db
        .prepare('SELECT * FROM trades WHERE telegram_channel_id = ? AND telegram_message_id = ?')
        .get(input.telegramChannelId, input.telegramMessageId) as Record<string, unknown> | undefined;

      return raw ? rowToTrade(toTradeRow(raw)) : null;
    } catch (err) {
      if (err instanceof Error && err.message.includes('UNIQUE constraint failed')) {
        logger.debug(
          `Duplicate message: channel=${input.telegramChannelId} msg=${input.telegramMessageId}, skipping`,
        );
        return this.findByMessageId(input.telegramChannelId, input.telegramMessageId);
      }
      throw err;
    }
  }

  /**
   * Insert a new trade record with analysis results.
   * Returns the newly created trade (with auto-generated id).
   */
  create(input: CreateTradeInput): Trade {
    const now = new Date().toISOString();
    const processedAt = input.telegramMessageTime.toISOString(); // Will be overwritten if reprocessed

    try {
      const stmt = this.db.prepare(`
        INSERT INTO trades (
          telegram_message_id,
          telegram_channel_id,
          telegram_message_time,
          symbol,
          option_type,
          strike,
          quantity,
          confidence,
          detection_method,
          image_path,
          processed_at,
          inserted_at,
          parser_version,
          caption
        ) VALUES (
          @telegramMessageId,
          @telegramChannelId,
          @telegramMessageTime,
          @symbol,
          @optionType,
          @strike,
          @quantity,
          @confidence,
          @detectionMethod,
          @imagePath,
          @processedAt,
          @insertedAt,
          @parserVersion,
          @caption
        )
      `);

      const result = stmt.run({
        telegramMessageId: input.telegramMessageId,
        telegramChannelId: input.telegramChannelId,
        telegramMessageTime: input.telegramMessageTime.toISOString(),
        symbol: input.analysis.symbol,
        optionType: input.analysis.optionType,
        strike: null,
        quantity: null,
        confidence: input.analysis.confidence,
        detectionMethod: input.analysis.method,
        imagePath: input.imagePath,
        processedAt,
        insertedAt: now,
        parserVersion: input.parserVersion,
        caption: input.caption,
      });

      const id = result.lastInsertRowid as number;
      logger.debug(`Inserted trade id=${id} message=${input.telegramMessageId}`);

      return this.findById(id)!;
    } catch (err) {
      // Unique constraint violation — message already processed
      if (err instanceof Error && err.message.includes('UNIQUE constraint failed')) {
        logger.warn(
          `Duplicate message: channel=${input.telegramChannelId} msg=${input.telegramMessageId}, skipping`,
        );
        return this.findByMessageId(input.telegramChannelId, input.telegramMessageId)!;
      }
      throw err;
    }
  }

  // -----------------------------------------------------------------------
  // Read
  // -----------------------------------------------------------------------

  /** Find a trade by its primary key. */
  findById(id: number): Trade | null {
    const raw = this.db
      .prepare('SELECT * FROM trades WHERE id = ?')
      .get(id) as Record<string, unknown> | undefined;
    return raw ? rowToTrade(toTradeRow(raw)) : null;
  }

  /** Find a trade by its Telegram channel + message ID. */
  findByMessageId(channelId: string, messageId: number): Trade | null {
    const raw = this.db
      .prepare('SELECT * FROM trades WHERE telegram_channel_id = ? AND telegram_message_id = ?')
      .get(channelId, messageId) as Record<string, unknown> | undefined;
    return raw ? rowToTrade(toTradeRow(raw)) : null;
  }

  /** Get all trades, ordered by message time (oldest first). */
  findAll(): Trade[] {
    const rows = this.db
      .prepare('SELECT * FROM trades ORDER BY telegram_message_time ASC')
      .all() as Record<string, unknown>[];
    return rows.map((r) => rowToTrade(toTradeRow(r)));
  }

  /** Get trades that need human review (confidence < 70). */
  findNeedingReview(): Trade[] {
    const rows = this.db
      .prepare('SELECT * FROM trades WHERE confidence < 70 ORDER BY telegram_message_time ASC')
      .all() as Record<string, unknown>[];
    return rows.map((r) => rowToTrade(toTradeRow(r)));
  }

  /** Get trades for a specific symbol. */
  findBySymbol(symbol: string): Trade[] {
    const rows = this.db
      .prepare('SELECT * FROM trades WHERE symbol = ? ORDER BY telegram_message_time ASC')
      .all(symbol) as Record<string, unknown>[];
    return rows.map((r) => rowToTrade(toTradeRow(r)));
  }

  /** Get trades that have not been analyzed yet (symbol is NULL). */
  findUnanalyzed(): Trade[] {
    const rows = this.db
      .prepare('SELECT * FROM trades WHERE symbol IS NULL ORDER BY telegram_message_time ASC')
      .all() as Record<string, unknown>[];
    return rows.map((r) => rowToTrade(toTradeRow(r)));
  }

  /** Count total trades in the database. */
  count(): number {
    const row = this.db.prepare('SELECT COUNT(*) as cnt FROM trades').get() as { cnt: number };
    return row.cnt;
  }

  /** Count trades per symbol. */
  countBySymbol(): Record<string, number> {
    const rows = this.db
      .prepare('SELECT symbol, COUNT(*) as cnt FROM trades GROUP BY symbol')
      .all() as { symbol: string; cnt: number }[];
    const result: Record<string, number> = {};
    for (const r of rows) {
      result[r.symbol ?? 'NULL'] = r.cnt;
    }
    return result;
  }

  // -----------------------------------------------------------------------
  // Update
  // -----------------------------------------------------------------------

  /**
   * Update the analysis results for an existing trade.
   * Used when reprocessing images with a newer parser version.
   */
  updateAnalysis(
    id: number,
    analysis: {
      symbol: string | null;
      optionType: string | null;
      confidence: number;
      method: string | null;
      parserVersion: string;
    },
  ): void {
    const now = new Date().toISOString();
    this.db
      .prepare(`
        UPDATE trades SET
          symbol = @symbol,
          option_type = @optionType,
          confidence = @confidence,
          detection_method = @method,
          processed_at = @processedAt,
          parser_version = @parserVersion,
          updated_at = @updatedAt
        WHERE id = @id
      `)
      .run({
        id,
        symbol: analysis.symbol,
        optionType: analysis.optionType,
        confidence: analysis.confidence,
        method: analysis.method,
        processedAt: now,
        parserVersion: analysis.parserVersion,
        updatedAt: now,
      });
    logger.debug(`Updated trade id=${id} with parser v${analysis.parserVersion}`);
  }

  // -----------------------------------------------------------------------
  // Delete
  // -----------------------------------------------------------------------

  /** Delete a trade by ID. */
  deleteById(id: number): boolean {
    const result = this.db.prepare('DELETE FROM trades WHERE id = ?').run(id);
    return result.changes > 0;
  }

  /** Delete all trades (useful for reprocessing). */
  deleteAll(): number {
    const result = this.db.prepare('DELETE FROM trades').run();
    logger.warn(`Deleted all trades: ${result.changes} rows`);
    return result.changes;
  }
}