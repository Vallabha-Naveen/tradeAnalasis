/**
 * SQLite schema definition.
 *
 * All DDL lives here. Call `runMigrations(db)` once at startup.
 */

import type { Database } from 'better-sqlite3';

/** SQL statements executed in order */
const MIGRATIONS = [
  `
    CREATE TABLE IF NOT EXISTS trades (
      id                    INTEGER PRIMARY KEY AUTOINCREMENT,

      -- Telegram metadata
      telegram_message_id   INTEGER    NOT NULL,
      telegram_channel_id   TEXT       NOT NULL,
      telegram_message_time TEXT       NOT NULL,   -- ISO 8601

      -- Trade data (nullable in early parser versions)
      symbol                TEXT       DEFAULT NULL,
      option_type           TEXT       DEFAULT NULL,
      strike                REAL       DEFAULT NULL,
      quantity              INTEGER    DEFAULT NULL,

      -- Detection metadata
      confidence            REAL       NOT NULL DEFAULT 0,
      detection_method      TEXT       DEFAULT NULL,

      -- Image reference
      image_path            TEXT       NOT NULL,

      -- Processing metadata
      processed_at          TEXT       NOT NULL,   -- ISO 8601
      inserted_at           TEXT       NOT NULL,   -- ISO 8601
      parser_version        TEXT       NOT NULL DEFAULT '0.1.0',

      -- Message caption
      caption               TEXT       NOT NULL DEFAULT '',

      -- Timestamps
      created_at            TEXT       NOT NULL DEFAULT (datetime('now')),
      updated_at            TEXT       NOT NULL DEFAULT (datetime('now'))
    );
  `,
  `
    CREATE UNIQUE INDEX IF NOT EXISTS idx_trades_message
      ON trades (telegram_channel_id, telegram_message_id);
  `,
  `
    CREATE INDEX IF NOT EXISTS idx_trades_symbol
      ON trades (symbol);
  `,
  `
    CREATE INDEX IF NOT EXISTS idx_trades_message_time
      ON trades (telegram_message_time);
  `,
  `
    CREATE INDEX IF NOT EXISTS idx_trades_confidence
      ON trades (confidence);
  `,
  `
    CREATE INDEX IF NOT EXISTS idx_trades_needs_review
      ON trades (confidence)
      WHERE confidence < 70;
  `,
];

/**
 * Run all pending migrations against the database.
 * Safe to call multiple times — each statement uses IF NOT EXISTS.
 *
 * @param db - open better-sqlite3 Database instance
 */
export function runMigrations(db: Database): void {
  for (const sql of MIGRATIONS) {
    db.exec(sql);
  }
}